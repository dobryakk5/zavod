/* eslint-disable react-hooks/exhaustive-deps */
'use client';

import { useEffect, useMemo, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Check, CheckCircle2, Hammer, Info, Loader2, RefreshCw, Search, Trash2, X } from 'lucide-react';
import { toast } from 'sonner';
import { ApiError } from '@/lib/api';
import { seoApi } from '@/lib/api/seo';
import { semanticGroupsApi } from '@/lib/api/semantic-groups';
import { wordstatApi } from '@/lib/api/wordstat';
import { googleApi } from '@/lib/api/google';
import type {
  GoogleCompetitorsResolvedRow,
  GoogleCseSearchResult,
  SemanticGroup,
  SEOKeywordSet,
  SEOStatus,
  WordstatQuery
} from '@/lib/types';
import { useRole, useTenantTimezone } from '@/lib/hooks';
import { formatInTenantTimezone } from '@/lib/timezone';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

const GROUP_LABELS: Record<string, string> = {
  seo_keywords: 'SEO ключевые фразы',
  seo_pains: 'Боли аудитории',
  seo_desires: 'Желания аудитории',
  seo_objections: 'Возражения и страхи',
  seo_avatar: 'Аватары клиентов',
  legacy: 'Другие группы',
  '': 'Неразмеченная группа',
};

const GROUP_DESCRIPTIONS: Record<string, string> = {
  seo_keywords: 'Готовые низко- и среднечастотные поисковые запросы для текстов и рилс.',
  seo_pains: 'Фразы, которыми описывают свои проблемы потенциальные клиенты.',
  seo_desires: 'Что пользователи ищут, когда хотят получить ваш продукт/услугу.',
  seo_objections: 'Чего боятся и какие вопросы задают перед покупкой.',
  seo_avatar: 'Самоописания и профессии целевой аудитории.',
  legacy: 'Исторические подборки, созданные в ранних версиях конструктора.',
  '': 'Подборка без указанного типа (наследие ранних версий).',
};

const STATUS_LABELS: Record<SEOStatus, string> = {
  pending: 'Ожидает',
  generating: 'Генерация',
  completed: 'Готово',
  failed: 'Ошибка',
};

const STATUS_STYLES: Record<SEOStatus, string> = {
  pending: 'bg-slate-100 text-slate-700',
  generating: 'bg-blue-100 text-blue-800',
  completed: 'bg-emerald-100 text-emerald-800',
  failed: 'bg-red-100 text-red-800',
};

const GROUP_ORDER = ['seo_keywords', 'seo_pains', 'seo_desires', 'seo_objections', 'seo_avatar', 'legacy'];

function formatDate(value: string | null | undefined, timeZone: string) {
  if (!value) return '—';
  try {
    return formatInTenantTimezone(value, timeZone, {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }) || value;
  } catch {
    return value;
  }
}

function getKeywords(set: SEOKeywordSet): string[] {
  if (Array.isArray(set.keywords_list) && set.keywords_list.length) {
    return set.keywords_list;
  }
  if (set.keyword_groups) {
    return Object.values(set.keyword_groups)
      .flat()
      .filter((item): item is string => Boolean(item));
  }
  return [];
}

function StatusBadge({ status }: { status: SEOStatus }) {
  return (
    <Badge className={`${STATUS_STYLES[status] ?? ''} text-xs font-medium`}>
      {STATUS_LABELS[status] ?? status}
    </Badge>
  );
}

const getVisibleErrorLog = (set: { status: SEOStatus; error_log?: string | null }) => {
  const raw = (set.error_log || '').trim();
  if (!raw) return '';
  const filtered = raw
    .split('\n')
    .filter((line) => !line.toLowerCase().includes('literal_eval'))
    .join('\n')
    .trim();
  return filtered;
};

const shouldShowErrorLog = (set: { status: SEOStatus; error_log?: string | null }) =>
  set.status === 'failed' && Boolean(getVisibleErrorLog(set));

const normalizeUrlForCompare = (value?: string | null) => (value || '').trim().replace(/\/+$/, '').toLowerCase();

const getRootDomain = (value?: string | null) => {
  const raw = (value || '').trim().toLowerCase();
  if (!raw) return '';
  let host = raw;
  try {
    if (raw.includes('://')) {
      host = new URL(raw).hostname;
    } else {
      host = raw.split('/')[0];
    }
  } catch {
    host = raw.split('/')[0];
  }
  host = host.replace(/:\d+$/, '').replace(/^www\./, '');
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return host;
  const parts = host.split('.').filter(Boolean);
  if (parts.length <= 2) return host;
  return parts.slice(-2).join('.');
};

const getDomainKeyFromRow = (row: GoogleCompetitorsResolvedRow) => {
  return (
    getRootDomain(row.domain) ||
    getRootDomain(row.url) ||
    (row.domain || '').trim().toLowerCase() ||
    (row.url || '').trim().toLowerCase()
  );
};

const buildUniqueSnippet = (value: string, maxLen: number = 240) => {
  const text = (value || '').replace(/\s+/g, ' ').trim();
  if (!text) return '';

  const rawParts = text.split(/(?<=[.!?…])\s+/).map((s) => s.trim()).filter(Boolean);
  if (rawParts.length <= 1) return text.slice(0, maxLen);

  const seen = new Set<string>();
  const out: string[] = [];
  for (const part of rawParts) {
    const key = part.toLowerCase().replace(/\s+/g, ' ').replace(/[^\p{L}\p{N}\s]+/gu, '').trim();
    if (!key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(part);
    if (out.join(' ').length >= maxLen) break;
  }

  const joined = out.join(' ');
  return joined.length > maxLen ? joined.slice(0, maxLen) : joined;
};

export default function SEOPageClient() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { timezone: tenantTimezone } = useTenantTimezone();
  const [activeTab, setActiveTab] = useState<'groups' | 'seo' | 'wordstat' | 'competitors'>('groups');
  const [seoSets, setSeoSets] = useState<SEOKeywordSet[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [restarting, setRestarting] = useState(false);
  const [semanticGroups, setSemanticGroups] = useState<SemanticGroup[]>([]);
  const [semanticGroupsLoading, setSemanticGroupsLoading] = useState(true);
  const [semanticGroupsRefreshing, setSemanticGroupsRefreshing] = useState(false);
  const [semanticGroupClustering, setSemanticGroupClustering] = useState<Record<number, boolean>>({});
  const [creatingSemanticGroup, setCreatingSemanticGroup] = useState(false);
  const [newSemanticGroup, setNewSemanticGroup] = useState({
    name: '',
    description: '',
    scope: 'normal',
    expected_clusters: '',
    status: 'draft',
  });
  const [wordstatQueries, setWordstatQueries] = useState<WordstatQuery[]>([]);
  const [wordstatLoading, setWordstatLoading] = useState(true);
  const [wordstatRefreshing, setWordstatRefreshing] = useState(false);
  const [wordstatSubmitting, setWordstatSubmitting] = useState(false);
  const [wordstatGroup, setWordstatGroup] = useState('');
  const [selectedQueryId, setSelectedQueryId] = useState<number | null>(null);
  const [phraseCounts, setPhraseCounts] = useState<Record<string, number>>({});
  const [historyEdits, setHistoryEdits] = useState<Record<number, string>>({});
  const [groupNameEdits, setGroupNameEdits] = useState<Record<number, string>>({});
  const [deletingQueries, setDeletingQueries] = useState<Record<number, boolean>>({});
  const [googleSearching, setGoogleSearching] = useState(false);
  const [googleQuery, setGoogleQuery] = useState<string | null>(null);
  const [googleResults, setGoogleResults] = useState<GoogleCseSearchResult[]>([]);
  const [resolvedResults, setResolvedResults] = useState<GoogleCompetitorsResolvedRow[]>([]);
  const [competitorPhrase, setCompetitorPhrase] = useState<string>('');
  const [competitorPhraseDraft, setCompetitorPhraseDraft] = useState<string>('');
  const [competitorFilters, setCompetitorFilters] = useState<{
    unsorted: boolean;
    competitors: boolean;
    informational: boolean;
    indirect: boolean;
    other: boolean;
  }>({
    unsorted: true,
    competitors: false,
    informational: false,
    indirect: false,
    other: false,
  });
  const [competitorSitesLoading, setCompetitorSitesLoading] = useState(false);
  const [manualCompetitor, setManualCompetitor] = useState('');
  const [autoGoogle, setAutoGoogle] = useState(false);
  const [autoGoogleDoneFor, setAutoGoogleDoneFor] = useState<string | null>(null);
  const [activeCompetitorDomain, setActiveCompetitorDomain] = useState<string | null>(null);
  const [projectDataDialogOpen, setProjectDataDialogOpen] = useState(false);
  const { canEdit } = useRole();

  const loadSeoSets = async (opts?: { silent?: boolean }) => {
    if (opts?.silent) {
      setRefreshing(true);
    } else {
      setLoading(true);
    }
    try {
      const data = await seoApi.list();
      setSeoSets(data);
    } catch (error) {
      console.error('Failed to load SEO keyword sets', error);
      toast.error('Не удалось загрузить SEO группы');
    } finally {
      if (opts?.silent) {
        setRefreshing(false);
      } else {
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    loadSeoSets();
  }, []);

  const loadSemanticGroups = async (opts?: { silent?: boolean }) => {
    if (opts?.silent) {
      setSemanticGroupsRefreshing(true);
    } else {
      setSemanticGroupsLoading(true);
    }
    try {
      const data = await semanticGroupsApi.list();
      setSemanticGroups(data);
    } catch (error) {
      console.error('Failed to load semantic groups', error);
      toast.error('Не удалось загрузить смысловые группы');
    } finally {
      setSemanticGroupsLoading(false);
      if (opts?.silent) {
        setSemanticGroupsRefreshing(false);
      }
    }
  };

  useEffect(() => {
    loadSemanticGroups();
  }, []);

  const loadWordstatQueries = async (opts?: { silent?: boolean }) => {
    if (opts?.silent) {
      setWordstatRefreshing(true);
    } else {
      setWordstatLoading(true);
    }
    try {
      const data = await wordstatApi.list();
      setWordstatQueries(data);
      if (!selectedQueryId && data.length) {
        setSelectedQueryId(data[0].id);
      }
    } catch (error) {
      console.error('Failed to load Wordstat history', error);
      toast.error('Не удалось загрузить историю Wordstat');
    } finally {
      setWordstatLoading(false);
      if (opts?.silent) {
        setWordstatRefreshing(false);
      }
    }
  };

  useEffect(() => {
    loadWordstatQueries({ silent: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const grouped = useMemo(() => {
    const map: Record<string, SEOKeywordSet[]> = {};
    seoSets.forEach((set) => {
      const key = set.group_type || 'legacy';
      if (!map[key]) {
        map[key] = [];
      }
      map[key].push(set);
    });
    return map;
  }, [seoSets]);

  const orderedGroups = useMemo(() => {
    const known = GROUP_ORDER.filter((key) => grouped[key]?.length);
    const rest = Object.keys(grouped).filter((key) => !GROUP_ORDER.includes(key));
    return [...known, ...rest];
  }, [grouped]);

  const selectedWordstatQuery = useMemo(() => {
    if (selectedQueryId) {
      const found = wordstatQueries.find((item) => item.id === selectedQueryId);
      if (found) {
        return found;
      }
    }
    return wordstatQueries[0];
  }, [selectedQueryId, wordstatQueries]);

  const favoriteResults = useMemo(() => {
    const result: { phrase: string; count: number; queryId: number }[] = [];
    wordstatQueries.forEach((q) => {
      q.results
        .filter((r) => r.result_type === 'favorite')
        .forEach((r) => result.push({ phrase: r.phrase, count: r.count, queryId: q.id }));
    });
    return result;
  }, [wordstatQueries]);

  const topFavorite = useMemo(() => {
    const bestByPhrase = new Map<string, { phrase: string; count: number }>();
    favoriteResults.forEach((row) => {
      const phrase = (row.phrase || '').trim();
      if (!phrase) return;
      const prev = bestByPhrase.get(phrase);
      if (!prev || row.count > prev.count) {
        bestByPhrase.set(phrase, { phrase, count: row.count });
      }
    });
    const list = Array.from(bestByPhrase.values());
    list.sort((a, b) => b.count - a.count || a.phrase.localeCompare(b.phrase));
    return list[0] || null;
  }, [favoriteResults]);

  useEffect(() => {
    const tab = (searchParams.get('tab') || '').trim();
    if (tab === 'competitors' || tab === 'seo' || tab === 'wordstat' || tab === 'groups') {
      setActiveTab(tab as typeof activeTab);
    }
    const q = (searchParams.get('q') || '').trim();
    const fromFavorites = (searchParams.get('save') || '').trim() === '1';
    if (q && fromFavorites) {
      setCompetitorPhrase(q);
      setCompetitorPhraseDraft(q);
    }
    setAutoGoogle(fromFavorites);
  }, [searchParams]);

  const extractPhrases = (value: string) => {
    const seen = new Set<string>();
    return value
      .split(/\r?\n/)
      .map((item) => item.trim())
      .filter((item) => {
        if (!item || seen.has(item)) return false;
        seen.add(item);
        return true;
      });
  };

  const normalizePhraseList = (values: string[] = []) => {
    const seen = new Set<string>();
    const normalized: string[] = [];
    values.forEach((value) => {
      const text = (value || '').trim();
      if (text && !seen.has(text)) {
        seen.add(text);
        normalized.push(text);
      }
    });
    return normalized;
  };

  const getQueryText = (query: WordstatQuery) => {
    const list =
      Array.isArray(query.phrases) && query.phrases.length
        ? query.phrases
        : query.request_phrase
          ? [query.request_phrase]
          : [];
    return list.join('\n');
  };

  const getQueryTitle = (query: WordstatQuery) => {
    return (query.group_name || '').trim() || query.request_phrase || '';
  };

  const handleGenerateSEO = async () => {
    setGenerating(true);
    try {
      const response = await seoApi.generate();
      toast.success(response.message || 'Генерация SEO запущена');
      await loadSeoSets({ silent: true });
    } catch (error) {
      console.error('Failed to start SEO generation', error);
      if (error instanceof ApiError && error.status === 409) {
        toast.error('SEO генерация уже выполняется. Дождитесь завершения.');
      } else {
        toast.error('Не удалось запустить SEO-анализ');
      }
    } finally {
      setGenerating(false);
    }
  };

  const handleRestartSEO = async () => {
    if (restarting) return;
    setRestarting(true);
    try {
      const response = await seoApi.restart();
      toast.success(response.message || 'SEO генерация перезапущена');
      await loadSeoSets({ silent: true });
    } catch (error) {
      console.error('Failed to restart SEO generation', error);
      toast.error('Не удалось перезапустить SEO-анализ');
    } finally {
      setRestarting(false);
    }
  };

  const handleRefresh = () => loadSeoSets({ silent: true });

  const handleSemanticGroupsRefresh = () => loadSemanticGroups({ silent: true });


  const handleCreateSemanticGroup = async () => {
    if (!canEdit) return;
    const name = newSemanticGroup.name.trim();
    if (!name) {
      toast.error('Введите название смысловой группы');
      return;
    }
    setCreatingSemanticGroup(true);
    try {
      const parsedExpected = newSemanticGroup.expected_clusters
        ? Number.parseInt(newSemanticGroup.expected_clusters, 10)
        : null;
      const payload = {
        name,
        description: newSemanticGroup.description.trim(),
        scope: newSemanticGroup.scope || 'normal',
        status: newSemanticGroup.status || 'draft',
        expected_clusters: Number.isNaN(parsedExpected) ? null : parsedExpected,
        source: 'manual',
      };
      const created = await semanticGroupsApi.create(payload);
      setSemanticGroups((prev) => [created, ...prev]);
      setNewSemanticGroup({
        name: '',
        description: '',
        scope: 'normal',
        expected_clusters: '',
        status: 'draft',
      });
      toast.success('Смысловая группа создана');
    } catch (error) {
      console.error('Failed to create semantic group', error);
      toast.error('Не удалось создать смысловую группу');
    } finally {
      setCreatingSemanticGroup(false);
    }
  };

  const handleGenerateSemanticClusters = async (group: SemanticGroup) => {
    if (!canEdit) return;
    if (semanticGroupClustering[group.id]) return;
    setSemanticGroupClustering((prev) => ({ ...prev, [group.id]: true }));
    try {
      const response = await semanticGroupsApi.generateClusters(group.id);
      toast.success(response.message || 'Кластеры созданы');
      await loadSemanticGroups({ silent: true });
    } catch (error) {
      console.error('Failed to generate semantic clusters', error);
      if (error instanceof ApiError) {
        try {
          const payload = error.body ? JSON.parse(error.body) : null;
          if (payload?.missing_fields) {
            setProjectDataDialogOpen(true);
            return;
          }
          if (payload?.error) {
            toast.error(String(payload.error));
            return;
          }
        } catch {}
      }
      const message = error instanceof Error ? error.message : 'Не удалось создать кластеры';
      toast.error(message);
    } finally {
      setSemanticGroupClustering((prev) => ({ ...prev, [group.id]: false }));
    }
  };

  const fetchWordstatAndRedirect = async (payload: { phrase?: string; phrases?: string[]; group_name?: string }) => {
    const phrase = (payload.phrase || '').trim();
    const normalizedGroup = normalizePhraseList(payload.phrases);
    if (!phrase && normalizedGroup.length === 0) {
      toast.error('Введите фразу или группу фраз для запроса Wordstat');
      return;
    }

    const requestBody: Parameters<typeof wordstatApi.fetch>[0] = {};
    if (phrase) {
      requestBody.phrase = phrase;
    }
    if (normalizedGroup.length) {
      requestBody.phrases = normalizedGroup;
    }
    if (payload.group_name) {
      requestBody.group_name = payload.group_name.trim();
    }

    setWordstatSubmitting(true);
    try {
      const data = await wordstatApi.fetch(requestBody);
      const resultsCount = data.results?.length ?? 0;
      if (phrase || normalizedGroup.length === 1) {
        const key = phrase || normalizedGroup[0];
        setPhraseCounts((prev) => ({ ...prev, [key]: resultsCount }));
      }
      setWordstatQueries((prev) => [data, ...prev.filter((item) => item.id !== data.id)]);
      setSelectedQueryId(data.id);
      if (resultsCount > 0 && data.id) {
        window.location.href = `/seo/${data.id}`;
      }
    } catch (error) {
      console.error('Failed to fetch Wordstat', error);
      const message = error instanceof Error ? error.message : 'Не удалось получить Wordstat';
      toast.error(message);
    } finally {
      setWordstatSubmitting(false);
    }
  };

  const handleWordstatGroupFetch = () => {
    const phrases = extractPhrases(wordstatGroup);
    fetchWordstatAndRedirect({ phrases });
  };

  const rerunWordstatFromText = async (value: string, query?: WordstatQuery) => {
    const phrases = extractPhrases(value);
    const normalizedGroup = normalizePhraseList(phrases);

    if (query && query.id) {
      const existingSet = new Set<string>((query.phrases || []).map((item) => item.trim()));
      const newPhrases = normalizedGroup.filter((p) => !existingSet.has(p));
      if (newPhrases.length === 0) {
        toast.error('Новых фраз нет — добавьте строки, которых еще не было в группе');
        return;
      }
      setWordstatSubmitting(true);
      try {
        const data = await wordstatApi.append(Number(query.id), { phrases: newPhrases });
        setWordstatQueries((prev) => [data, ...prev.filter((item) => item.id !== data.id)]);
        setHistoryEdits((prev) => ({ ...prev, [query.id]: getQueryText(data) }));
        setGroupNameEdits((prev) => ({ ...prev, [query.id]: getQueryTitle(data) }));
        setSelectedQueryId(data.id);
        window.location.href = `/seo/${data.id}`;
        return;
      } catch (error) {
        console.error('Failed to append Wordstat phrases', error);
        const message = error instanceof Error ? error.message : 'Не удалось обновить Wordstat';
        toast.error(message);
      } finally {
        setWordstatSubmitting(false);
      }
    }

    fetchWordstatAndRedirect({ phrases: normalizedGroup });
  };

  const handleSaveGroupName = async (query: WordstatQuery, value: string) => {
    const name = value.trim().slice(0, 255);
    if (!query?.id) return;
    setWordstatSubmitting(true);
    try {
      const data = await wordstatApi.updateGroupName(Number(query.id), name);
      setWordstatQueries((prev) => [data, ...prev.filter((item) => item.id !== data.id)]);
      setGroupNameEdits((prev) => ({ ...prev, [query.id]: getQueryTitle(data) }));
    } catch (error) {
      console.error('Failed to update Wordstat group name', error);
      const message = error instanceof Error ? error.message : 'Не удалось обновить название группы';
      toast.error(message);
    } finally {
      setWordstatSubmitting(false);
    }
  };

  const handleDeleteQuery = async (query: WordstatQuery) => {
    if (!query?.id) return;
    setDeletingQueries((prev) => ({ ...prev, [query.id]: true }));
    try {
      await wordstatApi.remove(Number(query.id));
      setWordstatQueries((prev) => prev.filter((item) => item.id !== query.id));
      setSelectedQueryId((prev) => (prev === query.id ? null : prev));
      setHistoryEdits((prev) => {
        const next = { ...prev };
        delete next[query.id];
        return next;
      });
      setGroupNameEdits((prev) => {
        const next = { ...prev };
        delete next[query.id];
        return next;
      });
    } catch (error) {
      console.error('Failed to delete Wordstat query', error);
      const message = error instanceof Error ? error.message : 'Не удалось удалить запрос Wordstat';
      toast.error(message);
    } finally {
      setDeletingQueries((prev) => {
        const next = { ...prev };
        delete next[query.id];
        return next;
      });
    }
  };

  const handleWordstatRefresh = () => loadWordstatQueries({ silent: true });

  const handleGoogleSearch = async (phrase?: string) => {
    const query = (phrase ?? competitorPhrase ?? '').trim();
    if (!query) return;
    setGoogleSearching(true);
    setGoogleQuery(null);
    setGoogleResults([]);
    try {
      const data = await googleApi.cseSearch(query, 10);
      setGoogleQuery(data.query);
      setGoogleResults(data.results);
    } catch (err) {
      console.error('Failed to search in Google', err);
      if (err instanceof ApiError) {
        try {
          const payload = err.body ? JSON.parse(err.body) : null;
          const message = payload?.detail || payload?.error;
          if (message) {
            toast.error(String(message));
            return;
          }
        } catch {}
      }
      toast.error('Не удалось получить результаты Google');
    } finally {
      setGoogleSearching(false);
    }
  };

  const loadCachedCompetitors = async (phrase?: string | null) => {
    const q = (phrase || '').trim();
    setGoogleQuery(null);
    setGoogleResults([]);
    setCompetitorSitesLoading(true);
    try {
      const data = await googleApi.competitorsCached(q);
      setResolvedResults((prev) => mergeResolvedResults(prev, data.results));
    } catch (err) {
      console.error('Failed to load cached competitors', err);
    } finally {
      setCompetitorSitesLoading(false);
    }
  };

  const resolveCompetitors = async () => {
    const q = (googleQuery || '').trim();
    if (!q) return;
    if (!googleResults.length) return;
    setCompetitorSitesLoading(true);
    try {
      const resolved = await googleApi.competitorsResolve({
        query: q,
        results: googleResults.map((r, index) => ({ url: r.url, domain: r.domain, title: r.title, position: index + 1 })),
        max_results: 10
      });
      setResolvedResults((prev) => mergeResolvedResults(prev, resolved.results));
    } catch (err) {
      console.error('Failed to resolve competitors', err);
      toast.error('Не удалось обработать результаты Google');
    } finally {
      setCompetitorSitesLoading(false);
    }
  };

  const handleManualCompetitorMark = async (
    domain: string,
    category: 'competitor' | 'informational' | 'indirect' | 'other'
  ) => {
    const normalized = (domain || '').trim();
    if (!normalized) return;
    try {
      const res = await googleApi.competitorsMark(normalized, category);
      setResolvedResults((prev) =>
        prev.map((row) => {
          if (row.domain !== normalized) return row;
          const manual_is_competitor = res.manual_is_competitor;
          const manual_category = (res.manual_category as GoogleCompetitorsResolvedRow['manual_category']) ?? null;
          return {
            ...row,
            manual_is_competitor,
            manual_category,
            is_competitor: manual_is_competitor === null ? row.is_competitor : manual_is_competitor
          };
        })
      );
    } catch (err) {
      console.error('Failed to mark competitor', err);
      toast.error('Не удалось сохранить отметку');
    }
  };

  const handleManualAddCompetitor = async () => {
    const value = manualCompetitor.trim();
    if (!value) return;
    try {
      const resolved = await googleApi.competitorsResolve({
        query: competitorPhrase || '',
        results: [{ url: value, domain: value, title: '' }],
        max_results: 1
      });
      setResolvedResults((prev) => mergeResolvedResults(prev, resolved.results));
      setManualCompetitor('');
      toast.success('Сайт конкурента добавлен');
    } catch (err) {
      console.error('Failed to add competitor site', err);
      toast.error('Не удалось добавить сайт конкурента');
    }
  };

  const applyCompetitorPhrase = () => {
    const value = competitorPhraseDraft.trim();
    if (!value) {
      toast.error('Введите фразу для анализа конкурентов');
      return;
    }
    setCompetitorPhrase(value);
    setCompetitorPhraseDraft(value);
  };

  const mergeResolvedResults = (
    prev: GoogleCompetitorsResolvedRow[],
    incoming: GoogleCompetitorsResolvedRow[]
  ) => {
    if (!incoming.length) return prev;

    const next = [...prev];
    const indexByKey = new Map<string, number>();
    prev.forEach((row, idx) => {
      const key = getDomainKeyFromRow(row);
      if (key) {
        indexByKey.set(key, idx);
      }
    });

    let changed = false;
    incoming.forEach((row) => {
      const key = getDomainKeyFromRow(row);
      if (!key) return;
      const existingIndex = indexByKey.get(key);
      if (existingIndex === undefined) {
        indexByKey.set(key, next.length);
        next.push(row);
        changed = true;
        return;
      }
      const existing = next[existingIndex];
      const keys = Object.keys(row) as Array<keyof GoogleCompetitorsResolvedRow>;
      const isSame = keys.every((field) => existing[field] === row[field]);
      if (!isSame) {
        next[existingIndex] = { ...existing, ...row };
        changed = true;
      }
    });

    return changed ? next : prev;
  };

  const toggleCompetitorFilter = (key: 'unsorted' | 'competitors' | 'informational' | 'indirect' | 'other') => {
    setCompetitorFilters((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const activeCompetitorFilters = useMemo(
    () =>
      Object.entries(competitorFilters)
        .filter(([, isActive]) => isActive)
        .map(([key]) => key as 'unsorted' | 'competitors' | 'informational' | 'indirect' | 'other'),
    [competitorFilters]
  );

  const getCompetitorFilterKey = (row: GoogleCompetitorsResolvedRow) => {
    if (row.manual_category === 'competitor') return 'competitors';
    if (row.manual_category === 'informational') return 'informational';
    if (row.manual_category === 'indirect') return 'indirect';
    if (row.manual_category === 'other') return 'other';
    if (row.manual_is_competitor === true) return 'competitors';
    if (row.manual_is_competitor === false) return 'other';
    return 'unsorted';
  };

  const competitorCounts = useMemo(() => {
    const total = resolvedResults.length;
    const unsorted = resolvedResults.filter((row) => !row.manual_category && row.manual_is_competitor == null).length;
    const competitors = resolvedResults.filter(
      (row) =>
        row.manual_category === 'competitor' ||
        (row.manual_category == null && row.manual_is_competitor === true)
    ).length;
    const informational = resolvedResults.filter((row) => row.manual_category === 'informational').length;
    const indirect = resolvedResults.filter(
      (row) => row.manual_category === 'indirect'
    ).length;
    const other = resolvedResults.filter(
      (row) =>
        row.manual_category === 'other' ||
        (row.manual_category == null && row.manual_is_competitor === false)
    ).length;
    return { total, unsorted, competitors, informational, indirect, other };
  }, [resolvedResults]);

  const filteredCompetitorResults = useMemo(() => {
    if (!activeCompetitorFilters.length) return resolvedResults;
    return resolvedResults.filter((row) => activeCompetitorFilters.includes(getCompetitorFilterKey(row)));
  }, [resolvedResults, activeCompetitorFilters]);

  useEffect(() => {
    if (activeTab !== 'competitors') return;
    const handler = (event: KeyboardEvent) => {
      if (event.defaultPrevented) return;
      const target = event.target as HTMLElement | null;
      if (target) {
        const tag = target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || target.isContentEditable) return;
      }
      if (event.key !== '+' && event.key !== '-' && event.key !== '±') return;
      if (!activeCompetitorDomain) return;
      event.preventDefault();
      handleManualCompetitorMark(activeCompetitorDomain, 'indirect');
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [activeTab, activeCompetitorDomain]);

  useEffect(() => {
    if (activeTab !== 'competitors') return;
    const q = (competitorPhrase || '').trim();
    if (autoGoogle && q && autoGoogleDoneFor !== q) {
      if (!googleSearching) {
        setAutoGoogleDoneFor(q);
        handleGoogleSearch(q);
      }
      return;
    }
    loadCachedCompetitors(q);
  }, [activeTab, competitorPhrase]);

  useEffect(() => {
    if (activeTab !== 'competitors') return;
    resolveCompetitors();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, googleQuery, googleResults]);

  useEffect(() => {
    if (activeTab !== 'competitors') return;
    if (competitorSitesLoading) return;
    if (!resolvedResults.length) return;
    const hasPending = resolvedResults.some((r) => r.analysis_status === 'pending' || r.analysis_status === 'in_progress');
    if (!hasPending) return;
    const id = window.setTimeout(() => {
      resolveCompetitors();
    }, 5000);
    return () => window.clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeTab, resolvedResults, competitorSitesLoading]);

  return (
    <div className="space-y-6">
      <Dialog open={projectDataDialogOpen} onOpenChange={setProjectDataDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Введите данные проекта</DialogTitle>
            <DialogDescription>
              Для генерации заполните нишу, продукт и ЦА в настройках.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              type="button"
              onClick={() => {
                setProjectDataDialogOpen(false);
                router.push('/settings?tab=client');
              }}
            >
              Перейти к вводу
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold">SEO</h1>
        <p className="text-muted-foreground">
          Инструменты для SEO: готовые AI-группы и прямые выгрузки Wordstat по вашим фразам.
        </p>
      </div>

      <Tabs
        value={activeTab}
        onValueChange={(value) => setActiveTab(value as 'groups' | 'seo' | 'wordstat' | 'competitors')}
        className="space-y-6"
      >
        <TabsList>
          <TabsTrigger value="groups">Смыслы</TabsTrigger>
          <TabsTrigger value="seo">Запросы ЦА</TabsTrigger>
          <TabsTrigger value="wordstat">Wordstat</TabsTrigger>
          <TabsTrigger value="competitors">Конкуренты</TabsTrigger>
        </TabsList>

        <TabsContent value="groups" className="space-y-6">
          <div className="flex flex-col gap-2">
            <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="text-2xl font-semibold">Смыслы</h2>
                <p className="text-muted-foreground">
                  Смысловые группы, на которые разбивается тематика проекта. Формируются по книгам и редактируются вручную.
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={handleSemanticGroupsRefresh}
                  disabled={semanticGroupsLoading || semanticGroupsRefreshing}
                >
                  <RefreshCw className={`mr-2 h-4 w-4 ${semanticGroupsRefreshing ? 'animate-spin' : ''}`} />
                  Обновить
                </Button>
                <Button variant="outline" onClick={() => router.push('/settings?tab=client')}>
                  Перейти в настройки
                </Button>
              </div>
            </div>
            {!canEdit && (
              <p className="text-sm text-muted-foreground">
                У вас нет прав на редактирование смысловых групп. Попросите владельца или редактора аккаунта.
              </p>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Новая смысловая группа</CardTitle>
              <CardDescription>Добавьте новую группу вручную, если нужно дополнить карту смыслов.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid gap-3 md:grid-cols-2">
                <Input
                  placeholder="Название группы"
                  value={newSemanticGroup.name}
                  onChange={(e) => setNewSemanticGroup((prev) => ({ ...prev, name: e.target.value }))}
                  disabled={!canEdit || creatingSemanticGroup}
                />
                <div className="grid gap-2 md:grid-cols-2">
                  <Select
                    value={newSemanticGroup.scope}
                    onValueChange={(value) => setNewSemanticGroup((prev) => ({ ...prev, scope: value }))}
                    disabled={!canEdit || creatingSemanticGroup}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Ширина" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="narrow">Узкая</SelectItem>
                      <SelectItem value="normal">Средняя</SelectItem>
                      <SelectItem value="wide">Широкая</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select
                    value={newSemanticGroup.status}
                    onValueChange={(value) => setNewSemanticGroup((prev) => ({ ...prev, status: value }))}
                    disabled={!canEdit || creatingSemanticGroup}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Статус" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Черновик</SelectItem>
                      <SelectItem value="approved">Одобрено</SelectItem>
                      <SelectItem value="archived">Архив</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <Input
                  type="number"
                  placeholder="Ожидаемые кластеры"
                  value={newSemanticGroup.expected_clusters}
                  onChange={(e) => setNewSemanticGroup((prev) => ({ ...prev, expected_clusters: e.target.value }))}
                  disabled={!canEdit || creatingSemanticGroup}
                />
              </div>
              <Textarea
                placeholder="Описание: что входит и что не входит"
                value={newSemanticGroup.description}
                onChange={(e) => setNewSemanticGroup((prev) => ({ ...prev, description: e.target.value }))}
                disabled={!canEdit || creatingSemanticGroup}
                className="min-h-[90px]"
              />
              <div className="flex justify-end">
                <Button onClick={handleCreateSemanticGroup} disabled={!canEdit || creatingSemanticGroup}>
                  {creatingSemanticGroup ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Создаем...
                    </>
                  ) : (
                    'Добавить группу'
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {semanticGroupsLoading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Загружаем смысловые группы...
            </div>
          ) : semanticGroups.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Пока нет данных</CardTitle>
                <CardDescription>
                  Сначала соберите семантику по книгам в настройках или добавьте группы вручную.
                </CardDescription>
              </CardHeader>
            </Card>
          ) : (
            <div className="space-y-4">
              {semanticGroups.map((group) => {
                const clustering = Boolean(semanticGroupClustering[group.id]);
                const hasClusters = (group.clusters_count ?? 0) > 0;
                return (
                  <Card
                    key={group.id}
                    className="cursor-pointer transition hover:border-slate-300"
                    onClick={() => router.push(`/seo/group/${group.id}`)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        router.push(`/seo/group/${group.id}`);
                      }
                    }}
                  >
                    <CardContent className="flex items-start justify-between gap-3 py-4">
                      <div className="space-y-1">
                        <p className="text-sm font-semibold text-slate-900">{group.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {(group.description || '').trim() || 'Описание не указано'}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={(event) => {
                            event.stopPropagation();
                            handleGenerateSemanticClusters(group);
                          }}
                          disabled={!canEdit || clustering}
                          title="Создать кластеры"
                        >
                          {clustering ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Hammer className="h-4 w-4" />
                          )}
                        </Button>
                        {hasClusters && (
                          <span title="Кластеры созданы">
                            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="seo" className="space-y-6">
          <div className="flex flex-col gap-2">
            <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <h2 className="text-2xl font-semibold">SEO группы</h2>
                <p className="text-muted-foreground">
                  Ключевые поисковые фразы и инсайты, которые используют клиенты, когда ищут ваши продукты или услуги.
                </p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={handleRefresh} disabled={loading || refreshing}>
                  <RefreshCw className={`mr-2 h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
                  Обновить
                </Button>
                <Button onClick={handleGenerateSEO} disabled={!canEdit || generating}>
                  {generating ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Запуск...
                    </>
                  ) : (
                    'Запустить SEO-анализ'
                  )}
                </Button>
              </div>
            </div>
            {!canEdit && (
              <p className="text-sm text-muted-foreground">
                У вас нет прав на запуск генерации SEO. Попросите владельца или редактора аккаунта.
              </p>
            )}
          </div>

          {loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              Загружаем SEO группы...
            </div>
          ) : seoSets.length === 0 ? (
            <Card>
              <CardHeader>
                <CardTitle>Пока нет данных</CardTitle>
                <CardDescription>
                  Создайте SEO группы, чтобы увидеть, как клиенты ищут ваши товары и услуги. Нажмите «Запустить SEO-анализ».
                </CardDescription>
              </CardHeader>
            </Card>
          ) : (
            <>
              <div className="flex flex-col gap-4">
                {orderedGroups.map((group_key) => {
                  const sets = grouped[group_key];
                  if (!sets?.length) return null;
                  const latest = sets[0];
                  const keywords = getKeywords(latest);
                  const keywordGroupsEntries = latest.keyword_groups
                    ? Object.entries(latest.keyword_groups).filter(([, values]) => Array.isArray(values) && values.length)
                    : [];
                  const showKeywordGroups = keywordGroupsEntries.length > 0 && keywords.length === 0;
                  return (
                    <Card key={group_key}>
                      <CardHeader className="space-y-2">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <CardTitle>{GROUP_LABELS[group_key] ?? GROUP_LABELS.legacy}</CardTitle>
                            <CardDescription>{GROUP_DESCRIPTIONS[group_key] ?? GROUP_DESCRIPTIONS.legacy}</CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            <StatusBadge status={latest.status} />
                            {(latest.status === 'pending' || latest.status === 'generating') && (
                              <Button
                                type="button"
                                size="icon"
                                variant="ghost"
                                onClick={handleRestartSEO}
                                disabled={!canEdit || restarting}
                                title="Отменить и перезапустить SEO"
                              >
                                <RefreshCw className={`h-4 w-4 ${restarting ? 'animate-spin' : ''}`} />
                              </Button>
                            )}
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          Обновлено: {formatDate(latest.created_at, tenantTimezone)}
                          {latest.topic_name ? ` • Тема: ${latest.topic_name}` : ''}
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                      <p className="text-sm font-semibold">Ключевые фразы</p>
                      {keywords.length ? (
                        <ul className="mt-2 space-y-1 text-sm text-slate-700">
                          {keywords.map((keyword, idx) => (
                            <li key={`${keyword}-${idx}`}>
                              <button
                                type="button"
                                onClick={() => fetchWordstatAndRedirect({ phrases: [keyword] })}
                                className="text-left text-slate-800 underline-offset-2 hover:underline"
                              >
                                {keyword}
                              </button>
                              {typeof phraseCounts[keyword] === 'number' && (
                                <span className="ml-2 text-xs text-muted-foreground">
                                  ({phraseCounts[keyword]} фраз)
                                </span>
                              )}
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <p className="text-sm text-muted-foreground">Фразы появятся после завершения генерации.</p>
                      )}
                        </div>
                        {showKeywordGroups && (
                          <div className="space-y-2">
                            <p className="text-sm font-semibold">Группы запросов</p>
                            <div className="space-y-3 rounded-md border bg-slate-50 p-3">
                              {keywordGroupsEntries.map(([groupName, values]) => (
                                <div key={groupName}>
                                  <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
                                    {groupName || 'Группа'}
                                  </p>
                                  <ul className="mt-1 list-disc space-y-1 pl-4 text-sm text-slate-600">
                                    {values.map((value, index) => (
                                      <li key={`${groupName}-${value}-${index}`}>{value}</li>
                                    ))}
                                  </ul>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        {shouldShowErrorLog(latest) && (
                          <div className="rounded-md bg-red-50 p-3 text-sm text-red-600">
                            <p className="font-semibold">Ошибка генерации</p>
                            <p className="mt-1 whitespace-pre-wrap">{getVisibleErrorLog(latest)}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>История генераций</CardTitle>
                  <CardDescription>Последние запуски SEO-анализа по всем группам</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {seoSets.slice(0, 10).map((seoSet) => (
                    <div
                      key={seoSet.id}
                      className="flex flex-col gap-1 rounded-lg border p-3 sm:flex-row sm:items-center sm:justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold">
                            {GROUP_LABELS[seoSet.group_type] ?? GROUP_LABELS.legacy}
                          </p>
                          <StatusBadge status={seoSet.status} />
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(seoSet.created_at, tenantTimezone)}
                          {seoSet.topic_name ? ` • ${seoSet.topic_name}` : ''}
                        </p>
                        {shouldShowErrorLog(seoSet) && (
                          <p className="text-xs text-red-600">
                            Ошибка: {getVisibleErrorLog(seoSet).split('\n')[0]}
                          </p>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {seoSet.keywords_list?.length
                          ? `${seoSet.keywords_list.length} фраз`
                          : Object.values(seoSet.keyword_groups || {}).reduce(
                              (total, arr) => total + (arr?.length || 0),
                              0
                            ) + ' фраз'}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="wordstat" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Wordstat</CardTitle>
                <CardDescription>
                  Введите запросы построчно: строки отправятся в Wordstat и сохранятся в единую таблицу.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-semibold">Запрос</p>
                    <div className="flex flex-col gap-3">
                      <Textarea
                        placeholder="Каждая строка — отдельный запрос Wordstat"
                        value={wordstatGroup}
                        onChange={(e) => setWordstatGroup(e.target.value)}
                        className="min-h-[120px]"
                      />
                      <div className="flex w-full gap-2">
                        <Button type="button" disabled={!canEdit || wordstatSubmitting} onClick={handleWordstatGroupFetch} className="w-full">
                          {wordstatSubmitting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Запрос...
                            </>
                          ) : (
                            <>
                              <Search className="mr-2 h-4 w-4" />
                              Ищи запрос
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Строки опрашиваются по очереди, результаты объединяются в общий список для этой группы.
                    </p>
                  </div>
                </div>

                {!canEdit && (
                  <p className="text-sm text-muted-foreground">
                    У вас нет прав на отправку запросов Wordstat. Попросите владельца или редактора аккаунта.
                  </p>
                )}
              </CardContent>
            </Card>
          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle>История поисков</CardTitle>
                <CardDescription>Последние запросы Wordstat для этого клиента</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {wordstatLoading ? (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Загружаем историю...
                  </div>
                ) : wordstatQueries.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Запросы еще не отправлялись.</p>
                ) : (
                  <div className="space-y-2">
                    {favoriteResults.length > 0 && (
                      <button
                        type="button"
                        onClick={() => window.open('/seo/favorites', '_blank', 'noopener')}
                        className="w-full rounded-md border p-3 text-left transition hover:border-slate-400 border-slate-200 bg-white"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-semibold leading-tight">Избранное</p>
                          <Badge variant="outline" className="text-xs font-medium">
                            {favoriteResults.length} фраз
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground">Все отмеченные избранные фразы</p>
                      </button>
                    )}
                    {wordstatQueries.map((query) => {
                      const editedPhrase = historyEdits[query.id] ?? getQueryText(query);
                      const editedGroupName = groupNameEdits[query.id] ?? getQueryTitle(query);
                      const isGroupQuery = editedPhrase.includes('\n') || (query.phrases?.length ?? 0) > 1;
                      return (
                        <div
                          key={query.id}
                          className="w-full rounded-md border border-slate-200 bg-white p-3 transition hover:border-slate-400"
                        >
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-2">
                              <Input
                                value={editedGroupName}
                                onChange={(e) => setGroupNameEdits((prev) => ({ ...prev, [query.id]: e.target.value }))}
                                placeholder="Название группы"
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') {
                                    e.preventDefault();
                                    handleSaveGroupName(query, editedGroupName);
                                  }
                                }}
                                className="flex-1"
                              />
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleSaveGroupName(query, editedGroupName)}
                                disabled={wordstatSubmitting}
                              >
                                Сохранить
                              </Button>
                            </div>
                            <div className="flex items-start justify-between gap-2">
                              {isGroupQuery ? (
                                <Textarea
                                  value={editedPhrase}
                                  onChange={(e) =>
                                    setHistoryEdits((prev) => ({ ...prev, [query.id]: e.target.value }))
                                  }
                                  onKeyDown={(e) => {
                                    if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') {
                                      e.preventDefault();
                                      rerunWordstatFromText(editedPhrase, query);
                                    }
                                  }}
                                  className="min-h-[96px] flex-1"
                                />
                              ) : (
                                <Input
                                  value={editedPhrase}
                                  onChange={(e) =>
                                    setHistoryEdits((prev) => ({ ...prev, [query.id]: e.target.value }))
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      rerunWordstatFromText(editedPhrase, query);
                                    }
                                  }}
                                  className="flex-1"
                                />
                              )}
                              <Badge variant="outline" className="text-xs font-medium whitespace-nowrap">
                                {query.results?.length ?? 0} фраз
                              </Badge>
                            </div>
                            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
                              <span>
                                {formatDate(query.created_at, tenantTimezone)} • {query.total_count} показов
                              </span>
                              <div className="flex gap-2">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => window.open(`/seo/${query.id}`, '_blank', 'noopener')}
                                >
                                  Открыть
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => rerunWordstatFromText(editedPhrase, query)}
                                  disabled={wordstatSubmitting}
                                >
                                  Повторить
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDeleteQuery(query)}
                                  disabled={deletingQueries[query.id]}
                                  className="border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="competitors" className="space-y-6">
          <Card>
            <CardHeader className="space-y-2">
              <CardTitle>Конкуренты</CardTitle>
              <CardDescription>
                Поиск в Google по фразе Wordstat из избранного или введённой вручную.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <p className="text-sm font-semibold">Фраза для поиска</p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input
                    value={competitorPhraseDraft}
                    onChange={(e) => {
                      setCompetitorPhraseDraft(e.target.value);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        applyCompetitorPhrase();
                      }
                    }}
                    placeholder="Например: аудит сайта, продвижение в поиске"
                    className="flex-1"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={applyCompetitorPhrase}
                    disabled={!competitorPhraseDraft.trim()}
                  >
                    Использовать
                  </Button>
                </div>
                {topFavorite?.phrase === competitorPhrase ? (
                  <p className="text-xs text-muted-foreground">
                    {topFavorite.count.toLocaleString('ru-RU')} показов по Wordstat.
                  </p>
                ) : null}
              </div>

              {competitorPhrase ? (
                <div className="space-y-2">
                  <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div>
                      <p className="text-sm font-semibold">Используемая фраза</p>
                      <p className="text-sm text-slate-700">{competitorPhrase}</p>
                    </div>
                    <Button
                      type="button"
                      onClick={() => handleGoogleSearch(competitorPhrase)}
                      disabled={googleSearching || wordstatLoading}
                    >
                      {googleSearching ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Ищем...
                        </>
                      ) : (
                        'Найти в Google'
                      )}
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">
                  Введите фразу выше или отметьте фразы Wordstat как избранные, чтобы продолжить.
                </p>
              )}

              <div className="space-y-2">
                <p className="text-sm font-semibold">Добавить конкурента</p>
                <div className="flex flex-col gap-2 sm:flex-row">
                  <Input
                    value={manualCompetitor}
                    onChange={(e) => setManualCompetitor(e.target.value)}
                    placeholder="example.com или https://example.com"
                    className="flex-1"
                  />
                  <Button type="button" variant="outline" onClick={handleManualAddCompetitor} disabled={!manualCompetitor.trim()}>
                    Добавить
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {(competitorPhrase || resolvedResults.length > 0 || competitorSitesLoading) && (
            <Card>
              <CardHeader className="space-y-2">
                <CardTitle>Результаты Google</CardTitle>
                <CardDescription>
                  {resolvedResults.length
                    ? `${resolvedResults.length} сайтов`
                    : competitorSitesLoading
                      ? 'Загружаем сайты...'
                      : 'Пока нет данных — нажмите «Найти в Google»'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {resolvedResults.length === 0 ? (
                  competitorSitesLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Загружаем сайты...
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">
                      Нет сохранённых результатов для этой фразы. Нажмите «Найти в Google», чтобы собрать сайты.
                    </p>
                  )
                ) : (
                  <div className="space-y-3">
                    <div className="flex flex-wrap gap-2 text-sm">
                      <Badge
                        variant={competitorFilters.unsorted ? 'secondary' : 'outline'}
                        className="text-xs cursor-pointer"
                        onClick={() => toggleCompetitorFilter('unsorted')}
                      >
                        Несортированные: {competitorCounts.unsorted}
                      </Badge>
                      <Badge
                        variant={competitorFilters.competitors ? 'secondary' : 'outline'}
                        className="text-xs cursor-pointer"
                        onClick={() => toggleCompetitorFilter('competitors')}
                      >
                        Конкуренты: {competitorCounts.competitors}
                      </Badge>
                      <Badge
                        variant={competitorFilters.informational ? 'secondary' : 'outline'}
                        className="text-xs cursor-pointer"
                        onClick={() => toggleCompetitorFilter('informational')}
                      >
                        Информационные: {competitorCounts.informational}
                      </Badge>
                      <Badge
                        variant={competitorFilters.indirect ? 'secondary' : 'outline'}
                        className="text-xs cursor-pointer"
                        onClick={() => toggleCompetitorFilter('indirect')}
                      >
                        Косвенные: {competitorCounts.indirect}
                      </Badge>
                      <Badge
                        variant={competitorFilters.other ? 'secondary' : 'outline'}
                        className="text-xs cursor-pointer"
                        onClick={() => toggleCompetitorFilter('other')}
                      >
                        Остальные: {competitorCounts.other}
                      </Badge>
                    </div>
                    {filteredCompetitorResults.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Нет сайтов для выбранного фильтра.</p>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="w-[56px]">#</TableHead>
                            <TableHead className="w-[180px]">Домен</TableHead>
                            <TableHead>Сайт</TableHead>
                            <TableHead className="w-[140px]">Конкурент</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {filteredCompetitorResults.map((row) => {
                            const domainKey = getDomainKeyFromRow(row);
                            const displayDomain = getRootDomain(row.domain) || row.domain || '—';
                            return (
                              <TableRow
                                key={domainKey}
                                onMouseEnter={() => setActiveCompetitorDomain(domainKey)}
                                onFocusCapture={() => setActiveCompetitorDomain(domainKey)}
                              >
                          <TableCell className="tabular-nums text-muted-foreground">{row.position}</TableCell>
                          <TableCell>
                            <a
                              href={row.base_url || `https://${row.domain}/`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex underline-offset-2 hover:underline"
                            >
                              <Badge variant="outline" className="text-xs">
                                {displayDomain}
                              </Badge>
                            </a>
                            {row.cached ? (
                              <div className="mt-1 text-[10px] text-muted-foreground">из БД</div>
                            ) : null}
                            {row.last_seen_query ? (
                              <div className="mt-1 text-[10px] text-muted-foreground break-words">
                                фраза: {row.last_seen_query}
                              </div>
                            ) : null}
                            <div className="mt-2 flex flex-wrap gap-3">
                              {(() => {
                                const base = normalizeUrlForCompare(row.base_url || `https://${row.domain}/`);
                                const services = normalizeUrlForCompare(row.services_url);
                                const prices = normalizeUrlForCompare(row.prices_url);
                                const showServices = Boolean(services && services !== base && services !== prices);
                                const showPrices = Boolean(prices && prices !== base);
                                return (
                                  <>
                                    {showServices && row.services_url ? (
                                      <a
                                        href={row.services_url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs text-muted-foreground underline-offset-2 hover:underline"
                                      >
                                        услуги
                                      </a>
                                    ) : null}
                                    {showPrices && row.prices_url ? (
                                      <a
                                        href={row.prices_url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="text-xs text-muted-foreground underline-offset-2 hover:underline"
                                      >
                                        цены
                                      </a>
                                    ) : null}
                                  </>
                                );
                              })()}
                            </div>
                          </TableCell>
                          <TableCell>
                            <a
                              href={row.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-sm font-medium text-slate-900 underline-offset-2 hover:underline"
                            >
                              {row.title || row.base_url}
                            </a>
                            {row.home_text ? (
                              <p className="mt-1 text-xs text-muted-foreground">
                                {buildUniqueSnippet(row.home_text, 240)}
                              </p>
                            ) : (
                              <p className="mt-1 text-xs text-muted-foreground">Не удалось получить текст главной.</p>
                            )}
                            {row.one_liner &&
                            row.one_liner !== 'На главной нет ссылок на услуги и цены — не конкурент' ? (
                              <p className="mt-2 text-xs text-slate-700">{row.one_liner}</p>
                            ) : null}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => handleManualCompetitorMark(domainKey, 'competitor')}
                                onFocus={() => setActiveCompetitorDomain(domainKey)}
                                className={`rounded-md border p-2 transition ${
                                  row.manual_category === 'competitor'
                                    ? 'border-blue-200 bg-blue-50 text-blue-700'
                                    : 'border-slate-200 text-slate-400 hover:text-slate-600'
                                }`}
                                title="Конкурент"
                                aria-label="Конкурент"
                              >
                                <Check className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleManualCompetitorMark(domainKey, 'informational')}
                                onFocus={() => setActiveCompetitorDomain(domainKey)}
                                className={`rounded-md border p-2 transition ${
                                  row.manual_category === 'informational'
                                    ? 'border-amber-200 bg-amber-50 text-amber-800'
                                    : 'border-slate-200 text-slate-400 hover:text-slate-900'
                                }`}
                                title="Информационный"
                                aria-label="Информационный"
                              >
                                <Info className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleManualCompetitorMark(domainKey, 'indirect')}
                                onFocus={() => setActiveCompetitorDomain(domainKey)}
                                className={`rounded-md border px-2 py-1 text-xs font-semibold transition ${
                                  row.manual_category === 'indirect'
                                    ? 'border-slate-300 bg-slate-100 text-slate-900'
                                    : 'border-slate-200 text-slate-500 hover:text-slate-900'
                                }`}
                                title="Косвенный"
                                aria-label="Косвенный"
                              >
                                +-
                              </button>
                              <button
                                type="button"
                                onClick={() => handleManualCompetitorMark(domainKey, 'other')}
                                onFocus={() => setActiveCompetitorDomain(domainKey)}
                                className={`rounded-md border p-2 transition ${
                                  row.manual_category === 'other'
                                    ? 'border-slate-300 bg-slate-100 text-slate-900'
                                    : 'border-slate-200 text-slate-400 hover:text-slate-900'
                                }`}
                                title="Остальные"
                                aria-label="Остальные"
                              >
                                <X className="h-4 w-4" />
                              </button>
                            </div>
                          </TableCell>
                            </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

        </TabsContent>
      </Tabs>
    </div>
  );
}
