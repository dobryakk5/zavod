'use client';

import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { Button, type ButtonProps } from '@/components/ui/button';
import { toast } from 'sonner';
import { getVkConnectUrl } from '@/lib/api/vk';

interface VkConnectButtonProps {
  groupId?: string | number;
  onConnected?: () => void;
  disabled?: boolean;
  className?: string;
  children?: ReactNode;
  variant?: ButtonProps['variant'];
  size?: ButtonProps['size'];
}

/**
 * Opens VK OAuth flow in a popup window and triggers onConnected once it closes.
 */
export function VkConnectButton({
  groupId,
  onConnected,
  disabled,
  className,
  children,
  variant,
  size,
}: VkConnectButtonProps) {
  const [connecting, setConnecting] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const normalizedGroupId =
    typeof groupId === 'number' ? String(groupId) : (groupId ?? '').trim();

  const cleanupTimer = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      cleanupTimer();
    };
  }, [cleanupTimer]);

  const handleClick = () => {
    if (connecting) {
      return;
    }

    if (!normalizedGroupId) {
      toast.error('Укажите группу VK для подключения');
      return;
    }

    const popup = window.open(
      getVkConnectUrl({ groupId: normalizedGroupId }),
      'vk-connect',
      'width=600,height=720,resizable=yes,scrollbars=yes,status=yes',
    );

    if (!popup) {
      toast.error('Не удалось открыть окно авторизации VK');
      return;
    }

    setConnecting(true);
    popup.focus();

    cleanupTimer();
    timerRef.current = setInterval(() => {
      if (!popup || popup.closed) {
        cleanupTimer();
        setConnecting(false);
        onConnected?.();
      }
    }, 1000);
  };

  return (
    <Button
      type="button"
      onClick={handleClick}
      disabled={disabled || connecting}
      className={className}
      variant={variant}
      size={size}
    >
      {children ?? (connecting ? 'Ожидание авторизации...' : 'Подключить группу VK')}
    </Button>
  );
}
