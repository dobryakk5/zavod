from __future__ import annotations

# NOTE: This module is kept for backward-compatible imports and gradual refactors.
from datetime import timezone as dt_timezone

from django.db import transaction
from django.db.models import Prefetch, Q
from django.utils.dateparse import parse_datetime
from django.utils import timezone
from rest_framework import generics, status, viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView

from core import tasks
from core.generation_events import record_generation_event
from core.models import (
    CRMTask,
    CRMTaskHistory,
    ContentTemplate,
    GenerationEvent,
    Schedule,
    SocialAccount,
    Story,
    TelegramTask,
    Topic,
    TrendItem,
    UserTenantBinding,
)
from core.services.seo_generation import has_active_generation
from core.services.posting_service import update_post_status_after_publish
from core.social_accounts import sync_client_default_telegram_account

from .permissions import IsTenantMember, IsTenantOwnerOrEditor
from .serializers import (
    ContentTemplateSerializer,
    CRMTaskHistorySerializer,
    CRMTaskSerializer,
    ScheduleSerializer,
    SocialAccountSerializer,
    StoryDetailSerializer,
    StorySerializer,
    TelegramTaskSerializer,
    TopicDetailSerializer,
    TopicSerializer,
    TrendItemDetailSerializer,
    TrendItemSerializer,
)
from .utils import enforce_generation_limit, get_active_client
from .views_accounts import (
    ClientCustomDomainVerifyView,
    ClientExpertBooksView,
    ClientBookSemanticsView,
    GenerationEventSummaryView,
    ClientInfoView,
    ClientSettingsView,
    ClientSummaryView,
    LoginView,
    LogoutView,
    RefreshTokenView,
    TelegramAuthView,
)  # noqa: F401
from .views_integrations import (
    ChannelAnalysisViewSet,
    ProjectChannelAnalysisRunView,
    ProjectChannelAnalysisRunViewSet,
    VkCallbackView,
    VkConnectView,
    VkIntegrationViewSet,
    VkPublishView,
    WeeklySourceBatchViewSet,
    WeeklySourceReportViewSet,
    WeeklySourceRunView,
)  # noqa: F401
from .views_posts import PostsListView, PostToneViewSet, PostTypeViewSet, PostViewSet  # noqa: F401
from .views_products import (
    ClientProductViewSet,
    MindMapViewSet,
    MindNodePositionView,
    MindNodePropertyViewSet,
    ProductTypeViewSet,
)  # noqa: F401
from .views_seo import (
    ArticleViewSet,
    ProjectSemanticSetViewSet,
    SemanticClusterViewSet,
    SemanticGroupViewSet,
    SEOKeywordSetViewSet,
    WordstatClusterViewSet,
    WordstatQueryViewSet,
    WordstatResultViewSet,
)  # noqa: F401
from .views_social import DzenRSSFeedView, TgChannelView, _ensure_rss_account_for_client  # noqa: F401

class ScheduleListView(generics.ListAPIView):
    serializer_class = ScheduleSerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        queryset = (
            Schedule.objects.filter(client=client)
            .select_related("post", "social_account")
            .order_by("scheduled_at")
        )
        post_id = self.request.query_params.get("post")
        if post_id:
            queryset = queryset.filter(post_id=post_id)
        return queryset


class TelegramTaskListView(generics.ListAPIView):
    serializer_class = TelegramTaskSerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        return (
            TelegramTask.objects.filter(client=client)
            .order_by("-received_at", "-id")
        )


def _crm_tasks_access_q(user, client):
    tenant_contact_ids = UserTenantBinding.objects.filter(
        tenant_id=client.id,
        contact_id__isnull=False,
        contact_id__gt=0,
    ).values_list("contact_id", flat=True)
    return (
        Q(level__client=client)
        | (Q(level__isnull=True) & Q(created_by=user.id))
        | (Q(source="coaching") & Q(contact_id__in=tenant_contact_ids))
    )


def _parse_task_priority(value):
    if value in (None, ""):
        return None
    try:
        priority = int(value)
    except (TypeError, ValueError):
        raise ValueError("Некорректный priority.")
    if priority not in {1, 2, 3}:
        raise ValueError("Priority может быть только 1, 2 или 3.")
    return priority


def _parse_task_contact_id(value):
    if value in (None, ""):
        return None
    try:
        contact_id = int(value)
    except (TypeError, ValueError):
        raise ValueError("Некорректный contact_id.")
    if contact_id <= 0:
        raise ValueError("contact_id должен быть положительным.")
    return contact_id


def _tenant_has_contact(client_id: int, contact_id: int) -> bool:
    return UserTenantBinding.objects.filter(
        tenant_id=client_id,
        contact_id=contact_id,
        contact_id__gt=0,
    ).exists()


def _parse_task_due_at(value):
    if value in (None, ""):
        return None
    parsed = parse_datetime(str(value).strip())
    if parsed is None:
        raise ValueError("Некорректный due_at. Используйте ISO datetime.")
    if timezone.is_naive(parsed):
        parsed = timezone.make_aware(parsed, timezone=dt_timezone.utc)
    return parsed


class CRMTaskListCreateView(APIView):
    permission_classes = [IsTenantMember]

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsTenantOwnerOrEditor()]
        return super().get_permissions()

    def get(self, request):
        client = get_active_client(request.user)
        history_prefetch = Prefetch(
            "history_entries",
            queryset=CRMTaskHistory.objects.order_by("created_at", "id"),
        )
        queryset = (
            CRMTask.objects.select_related("level")
            .prefetch_related(history_prefetch)
            .filter(_crm_tasks_access_q(request.user, client))
            .order_by("-updated_at", "-id")
        )

        level_id = request.query_params.get("level_id")
        if level_id not in (None, ""):
            try:
                level_id_int = int(level_id)
            except (TypeError, ValueError):
                return Response({"error": "Некорректный level_id."}, status=status.HTTP_400_BAD_REQUEST)
            if not TelegramTask.objects.filter(id=level_id_int, client=client).exists():
                return Response({"error": "Обратная связь не найдена."}, status=status.HTTP_404_NOT_FOUND)
            queryset = queryset.filter(level_id=level_id_int)

        manual = request.query_params.get("manual")
        if manual in {"1", "true", "True"}:
            queryset = queryset.filter(level__isnull=True)
        elif manual in {"0", "false", "False"}:
            queryset = queryset.filter(level__isnull=False)

        contact_id = request.query_params.get("contact_id")
        if contact_id not in (None, ""):
            try:
                contact_id_int = _parse_task_contact_id(contact_id)
            except ValueError as exc:
                return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
            if not _tenant_has_contact(client.id, contact_id_int):
                return Response({"error": "Контакт не найден."}, status=status.HTTP_404_NOT_FOUND)
            queryset = queryset.filter(contact_id=contact_id_int)

        serializer = CRMTaskSerializer(queryset, many=True)
        return Response(serializer.data)

    def post(self, request):
        client = get_active_client(request.user)
        title = str(request.data.get("title") or "").strip()
        if not title:
            return Response({"error": "Поле title обязательно."}, status=status.HTTP_400_BAD_REQUEST)

        description_raw = request.data.get("description")
        description = str(description_raw).strip() if description_raw is not None else ""
        description = description or None

        level = None
        level_id = request.data.get("level_id")
        if level_id not in (None, ""):
            try:
                level_id_int = int(level_id)
            except (TypeError, ValueError):
                return Response({"error": "Некорректный level_id."}, status=status.HTTP_400_BAD_REQUEST)
            level = TelegramTask.objects.filter(id=level_id_int, client=client).first()
            if level is None:
                return Response({"error": "Обратная связь не найдена."}, status=status.HTTP_404_NOT_FOUND)

        try:
            priority = _parse_task_priority(request.data.get("priority"))
        except ValueError as exc:
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        if priority is None:
            priority = 2

        try:
            contact_id = _parse_task_contact_id(request.data.get("contact_id"))
        except ValueError as exc:
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)
        if contact_id is not None and not _tenant_has_contact(client.id, contact_id):
            return Response({"error": "Контакт не найден."}, status=status.HTTP_404_NOT_FOUND)

        try:
            due_at = _parse_task_due_at(request.data.get("due_at"))
        except ValueError as exc:
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

        task = CRMTask.objects.create(
            level=level,
            contact_id=contact_id,
            title=title,
            description=description,
            status="open",
            priority=priority,
            due_at=due_at,
            created_by=request.user.id,
        )
        serializer = CRMTaskSerializer(task)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class CRMTaskDetailView(APIView):
    permission_classes = [IsTenantMember]

    def get_object(self, request, task_id: int):
        client = get_active_client(request.user)
        history_prefetch = Prefetch(
            "history_entries",
            queryset=CRMTaskHistory.objects.order_by("created_at", "id"),
        )
        return (
            CRMTask.objects.select_related("level")
            .prefetch_related(history_prefetch)
            .filter(id=task_id)
            .filter(_crm_tasks_access_q(request.user, client))
            .first()
        )

    def get(self, request, task_id: int):
        task = self.get_object(request, task_id)
        if task is None:
            return Response({"error": "Задача не найдена."}, status=status.HTTP_404_NOT_FOUND)
        serializer = CRMTaskSerializer(task)
        return Response(serializer.data)


class CRMTaskHistoryListCreateView(APIView):
    permission_classes = [IsTenantMember]

    def get_permissions(self):
        if self.request.method == "POST":
            return [IsTenantOwnerOrEditor()]
        return super().get_permissions()

    def _get_task(self, request, task_id: int):
        client = get_active_client(request.user)
        return (
            CRMTask.objects.select_related("level")
            .filter(id=task_id)
            .filter(_crm_tasks_access_q(request.user, client))
            .first()
        )

    def get(self, request, task_id: int):
        task = self._get_task(request, task_id)
        if task is None:
            return Response({"error": "Задача не найдена."}, status=status.HTTP_404_NOT_FOUND)
        entries = task.history_entries.all().order_by("created_at", "id")
        serializer = CRMTaskHistorySerializer(entries, many=True)
        return Response(serializer.data)

    def post(self, request, task_id: int):
        task = self._get_task(request, task_id)
        if task is None:
            return Response({"error": "Задача не найдена."}, status=status.HTTP_404_NOT_FOUND)

        note = str(request.data.get("note") or "").strip()
        if not note:
            return Response({"error": "Поле note обязательно."}, status=status.HTTP_400_BAD_REQUEST)

        status_value = request.data.get("status")
        if status_value in (None, ""):
            status_value = None
        else:
            status_value = str(status_value).strip() or None

        try:
            priority = _parse_task_priority(request.data.get("priority"))
        except ValueError as exc:
            return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)

        with transaction.atomic():
            entry = CRMTaskHistory.objects.create(
                task=task,
                note=note,
                status=status_value,
                created_by=request.user.id,
            )
            task.updated_at = entry.created_at
            update_fields = ["updated_at"]
            if status_value is not None:
                task.status = status_value
                update_fields.append("status")
            if priority is not None:
                task.priority = priority
                update_fields.append("priority")
            task.save(update_fields=update_fields)

        serializer = CRMTaskHistorySerializer(entry)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

class TopicViewSet(viewsets.ModelViewSet):
    """ViewSet for Topic CRUD operations and content discovery"""

    permission_classes = [IsTenantMember]

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsTenantOwnerOrEditor()]
        return [IsTenantMember()]

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return TopicDetailSerializer
        return TopicSerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        return Topic.objects.filter(client=client).order_by('-created_at')

    def perform_create(self, serializer):
        client = get_active_client(self.request.user)
        serializer.save(client=client)

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def discover_content(self, request, pk=None):
        """Discover new content (trends) for this topic from enabled sources"""
        topic = self.get_object()

        # Call existing Celery task
        task = tasks.discover_content_for_topic.delay(topic.id)

        return Response({
            'success': True,
            'message': f'Content discovery started for topic: {topic.name}',
            'task_id': task.id
        })

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def generate_posts(self, request, pk=None):
        """Generate posts from all unused trends for this topic"""
        topic = self.get_object()

        limit_response = enforce_generation_limit(topic.client, GenerationEvent.EVENT_POST)
        if limit_response:
            return limit_response

        # Call existing Celery task
        task = tasks.generate_posts_for_topic.delay(topic.id)

        record_generation_event(
            topic.client,
            GenerationEvent.EVENT_POST,
            meta={"source": "topic", "topic_id": topic.id},
        )

        return Response({
            'success': True,
            'message': f'Post generation started for topic: {topic.name}',
            'task_id': task.id
        })

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def generate_seo(self, request, pk=None):
        """Generate SEO keywords for the topic's client"""
        topic = self.get_object()

        if has_active_generation(topic.client):
            return Response(
                {
                    'success': False,
                    'message': 'SEO генерация уже выполняется. Дождитесь завершения текущего запуска.',
                },
                status=status.HTTP_409_CONFLICT,
            )

        limit_response = enforce_generation_limit(topic.client, GenerationEvent.EVENT_SEO_GROUP)
        if limit_response:
            return limit_response

        # Trigger client-level SEO generation (deduplicated per client)
        task = tasks.generate_seo_keywords_for_client.delay(topic.client_id)

        record_generation_event(
            topic.client,
            GenerationEvent.EVENT_SEO_GROUP,
            meta={"source": "topic", "topic_id": topic.id},
        )

        return Response({
            'success': True,
            'message': f'SEO keyword generation started for client: {topic.client.name}',
            'task_id': task.id
        })


class TrendItemViewSet(viewsets.ModelViewSet):
    """ViewSet for TrendItem operations"""

    permission_classes = [IsTenantMember]

    def get_permissions(self):
        if self.action in ['destroy']:
            return [IsTenantOwnerOrEditor()]
        return [IsTenantMember()]

    def get_serializer_class(self):
        if self.action == 'retrieve':
            return TrendItemDetailSerializer
        return TrendItemSerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        queryset = TrendItem.objects.filter(client=client).order_by('-discovered_at')

        # Filter by topic if provided
        topic_id = self.request.query_params.get('topic')
        if topic_id:
            queryset = queryset.filter(topic_id=topic_id)

        # Filter unused trends
        unused_only = self.request.query_params.get('unused')
        if unused_only == 'true':
            queryset = queryset.filter(used_for_post__isnull=True)

        return queryset

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def generate_post(self, request, pk=None):
        """Generate a single post from this trend"""
        trend = self.get_object()

        limit_response = enforce_generation_limit(trend.client, GenerationEvent.EVENT_POST)
        if limit_response:
            return limit_response

        # Call existing Celery task
        task = tasks.generate_post_from_trend.delay(trend.id)

        record_generation_event(
            trend.client,
            GenerationEvent.EVENT_POST,
            meta={"source": "trend", "trend_id": trend.id},
        )

        return Response({
            'success': True,
            'message': f'Post generation started from trend: {trend.title}',
            'task_id': task.id
        })

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def generate_story(self, request, pk=None):
        """Generate a story (mini-series) from this trend"""
        trend = self.get_object()
        episode_count = request.data.get('episode_count', 3)

        # Call existing Celery task
        task = tasks.generate_story_from_trend.delay(trend.id, episode_count)

        return Response({
            'success': True,
            'message': f'Story generation started with {episode_count} episodes',
            'task_id': task.id
        })


class StoryViewSet(viewsets.ModelViewSet):
    """ViewSet for Story CRUD operations"""

    permission_classes = [IsTenantMember]

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsTenantOwnerOrEditor()]
        return [IsTenantMember()]

    def get_serializer_class(self):
        if self.action in ['retrieve', 'create', 'update', 'partial_update']:
            return StoryDetailSerializer
        return StorySerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        return Story.objects.filter(client=client).order_by('-created_at')

    def perform_create(self, serializer):
        client = get_active_client(self.request.user)
        serializer.save(client=client)

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def generate_posts(self, request, pk=None):
        """Generate posts from story episodes"""
        story = self.get_object()

        limit_response = enforce_generation_limit(story.client, GenerationEvent.EVENT_POST)
        if limit_response:
            return limit_response

        # Call existing Celery task
        task = tasks.generate_posts_from_story.delay(story.id)

        record_generation_event(
            story.client,
            GenerationEvent.EVENT_POST,
            meta={"source": "story", "story_id": story.id},
        )

        return Response({
            'success': True,
            'message': f'Generating posts from story: {story.title}',
            'task_id': task.id
        })



class ContentTemplateViewSet(viewsets.ModelViewSet):
    """
    ViewSet for ContentTemplate CRUD operations.
    Language stays read-only; other fields (type, tone, length) are editable.
    """

    permission_classes = [IsTenantMember]

    serializer_class = ContentTemplateSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsTenantOwnerOrEditor()]
        return [IsTenantMember()]

    def get_queryset(self):
        client = get_active_client(self.request.user)
        queryset = ContentTemplate.objects.for_client(client).select_related("client").order_by('-created_at')
        if getattr(self, "action", None) in ['update', 'partial_update', 'destroy']:
            return queryset.filter(client=client)
        return queryset

    def perform_create(self, serializer):
        client = get_active_client(self.request.user)
        serializer.save(client=client)


class ScheduleViewSet(viewsets.ModelViewSet):
    """ViewSet for Schedule CRUD operations"""

    permission_classes = [IsTenantMember]
    serializer_class = ScheduleSerializer

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsTenantOwnerOrEditor()]
        return [IsTenantMember()]

    def get_queryset(self):
        client = get_active_client(self.request.user)
        queryset = Schedule.objects.filter(client=client).select_related(
            "post", "social_account", "connection"
        ).order_by('scheduled_at')
        post_id = self.request.query_params.get("post")
        if post_id:
            queryset = queryset.filter(post_id=post_id)
        return queryset

    def get_serializer_context(self):
        context = super().get_serializer_context()
        context["client"] = get_active_client(self.request.user)
        return context

    def perform_create(self, serializer):
        client = get_active_client(self.request.user)
        serializer.save(client=client)

    @action(detail=True, methods=['post'], permission_classes=[IsTenantOwnerOrEditor])
    def publish_now(self, request, pk=None):
        """Publish this schedule immediately"""
        schedule = self.get_object()

        connection = getattr(schedule, "connection", None)
        provider = connection.provider if connection else None
        social_account = getattr(schedule, "social_account", None)
        if social_account is None:
            client = schedule.client
            if provider and provider != "rss_zen":
                # Используем connection-only расписание
                pass
            else:
                social_account = _ensure_rss_account_for_client(client, request)
                if social_account:
                    schedule.social_account = social_account
                    schedule.save(update_fields=["social_account"])
                else:
                    return Response(
                        {"success": False, "error": "У расписания не указан социальный аккаунт"},
                        status=status.HTTP_400_BAD_REQUEST,
                    )

        # RSS Дзен — помечаем опубликованным сразу
        if social_account.platform == "rss_zen":
            feed_url = (social_account.access_token or "").strip()
            schedule.scheduled_at = timezone.now()
            schedule.status = "published"
            schedule.external_id = feed_url
            log_msg = "\n[SUCCESS] Отмечено для RSS Дзена (берётся из RSS ленты)"
            if feed_url:
                log_msg += f"\nFeed: {feed_url}"
            schedule.log = (schedule.log or "") + log_msg
            schedule.save(update_fields=["scheduled_at", "status", "external_id", "log"])
            update_post_status_after_publish(schedule.post)
            return Response({
                'success': True,
                'message': 'Опубликовано в RSS Дзене',
                'status': schedule.status,
            })

        # Call existing Celery task
        task = tasks.publish_schedule.delay(schedule.id)

        return Response({
            'success': True,
            'message': 'Publishing started',
            'task_id': task.id
        })


class SocialAccountViewSet(viewsets.ModelViewSet):
    """ViewSet for SocialAccount CRUD operations"""

    permission_classes = [IsTenantOwnerOrEditor]
    serializer_class = SocialAccountSerializer

    def get_queryset(self):
        client = get_active_client(self.request.user)
        sync_client_default_telegram_account(client)
        _ensure_rss_account_for_client(client, self.request)
        return SocialAccount.objects.filter(client=client).order_by('platform', 'name')

    def perform_create(self, serializer):
        client = get_active_client(self.request.user)
        serializer.save(client=client)
