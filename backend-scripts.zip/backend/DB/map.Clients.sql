-- 1. Клиенты
CREATE TABLE contacs (
    id          SERIAL PRIMARY KEY,
    name        TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT now()
);

-- 2. Теги (цели / боли / опыт)
CREATE TABLE tags (
    id          SERIAL PRIMARY KEY,
    type        TEXT NOT NULL CHECK (type IN ('goal', 'pain', 'experience')),
    value       TEXT NOT NULL,
    created_at  TIMESTAMP DEFAULT now(),
    UNIQUE (type, value)
);

-- 3. Связь клиент ↔ теги
CREATE TABLE contac_tags (
    contac_id  INTEGER NOT NULL REFERENCES contacs(id) ON DELETE CASCADE,
    tag_id     INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (contac_id, tag_id)
);

-- =====================================================
-- 1. Все теги конкретного клиента
-- =====================================================
CREATE OR REPLACE FUNCTION get_contac_tags(p_contac_id INTEGER)
RETURNS TABLE (
    contac_name TEXT,
    tag_type    TEXT,
    tag_value   TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        c.name,
        t.type,
        t.value
    FROM contacs c
    JOIN contac_tags ct ON ct.contac_id = c.id
    JOIN tags t ON t.id = ct.tag_id
    WHERE c.id = p_contac_id;
END;
$$;


-- =====================================================
-- 2. Клиенты по конкретному тегу
-- (цель / боль / опыт)
-- =====================================================
CREATE OR REPLACE FUNCTION get_contacs_by_tag(
    p_tag_type TEXT,
    p_tag_value TEXT
)
RETURNS TABLE (
    contac_id   INTEGER,
    contac_name TEXT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT DISTINCT
        c.id,
        c.name
    FROM contacs c
    JOIN contac_tags ct ON ct.contac_id = c.id
    JOIN tags t ON t.id = ct.tag_id
    WHERE t.type = p_tag_type
      AND t.value = p_tag_value;
END;
$$;


-- =====================================================
-- 3. Статистика по тегам
-- (сколько клиентов на каждый тег)
-- =====================================================
CREATE OR REPLACE FUNCTION get_tag_statistics()
RETURNS TABLE (
    tag_type      TEXT,
    tag_value     TEXT,
    contacs_count INTEGER
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        t.type,
        t.value,
        COUNT(ct.contac_id)::INTEGER AS contacs_count
    FROM tags t
    LEFT JOIN contac_tags ct ON ct.tag_id = t.id
    GROUP BY t.type, t.value
    ORDER BY t.type, contacs_count DESC;
END;
$$;
