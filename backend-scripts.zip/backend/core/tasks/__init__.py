"""
Celery tasks для Content Factory (Zavod).

Этот модуль экспортирует все задачи из подмодулей для обратной совместимости.

Структура:
- publishing.py    - публикация контента в соцсети (2 задачи)
- aggregation.py   - сбор трендов из различных источников (12 задач)
- generation.py    - генерация контента с помощью AI (10 задач)
- seo.py          - генерация SEO ключевых слов (2 задачи)
- articles.py     - генерация блоков статей и blueprint (3 задачи)
- scheduling.py    - автоматическое планирование публикаций (1 задача)
"""

# Publishing tasks (2)
from .publishing import (
    process_due_schedules,
    publish_schedule,
)

# Aggregation tasks (12)
from .aggregation import (
    discover_trends_for_topic,
    discover_trends_for_all_active_topics,
    discover_telegram_trends_for_topic,
    discover_rss_trends_for_topic,
    discover_youtube_trends_for_topic,
    discover_instagram_trends_for_topic,
    discover_google_trends_only,
    discover_news_from_all_sources,
    discover_vkontakte_trends_for_topic,
    discover_content_for_topic,
    discover_trends_for_topic_with_telegram,
    analyze_telegram_channel_task,
)

from .channel_analysis import (
    analyze_channel_task,
    analyze_project_channels_task,
    notify_project_channel_analysis_run,
    schedule_project_channel_analysis_daily,
)
from .weekly_sources import (
    run_weekly_sources_for_client,
    process_weekly_source,
)
from .website_scan import (
    run_website_scan_task,
    maybe_schedule_next_website_scan_for_client,
)
from .competitors import (
    analyze_competitor_site_task,
)
# Generation tasks (10)
from .generation import (
    generate_post_from_trend,
    generate_posts_for_topic,
    generate_posts_from_seo_keyword_set,
    generate_posts_from_custom_task,
    generate_posts_with_videos_from_custom_task,
    generate_posts_with_videos_from_seo_keyword_set,
    generate_videos_from_trend_item_description,
    generate_videos_for_posts,
    generate_image_for_post,
    generate_video_from_image,
    generate_story_from_trend,
    generate_posts_from_story,
    regenerate_post_text,
    generate_weekly_posts_from_template,
)

# Article tasks (3)
from .articles import (
    generate_article_blueprint_task,
    generate_article_blocks_task,
    generate_article_block_task,
)

# SEO tasks (2)
from .seo import (
    generate_seo_keywords_for_client,
    generate_seo_keywords_for_topic,
)

# Products tasks (3)
from .products import (
    generate_client_product_for_type_task,
    generate_core_product_task,
    generate_related_product_task,
)

# Scheduling tasks (1)
from .scheduling import (
    auto_schedule_story_posts,
)
from .meeting_reminders import (
    send_meeting_reminders,
)
from .payment_reminders import (
    send_payment_reminders,
)
from .task_deadline_reminders import (
    send_task_deadline_reminders,
)
from .chains import (
    chains_send_delayed_message,
    chains_check_timeout,
)
from .rag import (
    process_pending_kb_rag_indexing,
)
from .amocrm import (
    sync_crm_client_to_amocrm_contact_task,
    resync_all_crm_clients_to_amocrm_task,
    process_amocrm_contacts_webhook_task,
)

__all__ = [
    # Publishing (2)
    'process_due_schedules',
    'publish_schedule',

    # Aggregation (12)
    'discover_trends_for_topic',
    'discover_trends_for_all_active_topics',
    'discover_telegram_trends_for_topic',
    'discover_rss_trends_for_topic',
    'discover_youtube_trends_for_topic',
    'discover_instagram_trends_for_topic',
    'discover_google_trends_only',
    'discover_news_from_all_sources',
    'discover_vkontakte_trends_for_topic',
    'discover_content_for_topic',
    'discover_trends_for_topic_with_telegram',
    'analyze_telegram_channel_task',
    'analyze_channel_task',
    'analyze_project_channels_task',
    'notify_project_channel_analysis_run',
    'schedule_project_channel_analysis_daily',
    'run_weekly_sources_for_client',
    'process_weekly_source',
    'run_website_scan_task',
    'maybe_schedule_next_website_scan_for_client',
    'analyze_competitor_site_task',

    # Generation (10)
    'generate_post_from_trend',
    'generate_posts_for_topic',
    'generate_posts_from_seo_keyword_set',
    'generate_posts_from_custom_task',
    'generate_posts_with_videos_from_custom_task',
    'generate_posts_with_videos_from_seo_keyword_set',
    'generate_videos_from_trend_item_description',
    'generate_videos_for_posts',
    'generate_image_for_post',
    'generate_video_from_image',
    'generate_story_from_trend',
    'generate_posts_from_story',
    'regenerate_post_text',
    'generate_weekly_posts_from_template',

    # Articles (3)
    'generate_article_blueprint_task',
    'generate_article_blocks_task',
    'generate_article_block_task',

    # SEO (2)
    'generate_seo_keywords_for_client',
    'generate_seo_keywords_for_topic',

    # Products (3)
    'generate_client_product_for_type_task',
    'generate_core_product_task',
    'generate_related_product_task',

    # Scheduling (1)
    'auto_schedule_story_posts',

    # CRM reminders
    'send_meeting_reminders',
    'send_payment_reminders',
    'send_task_deadline_reminders',

    # Chains (2)
    'chains_send_delayed_message',
    'chains_check_timeout',
    'process_pending_kb_rag_indexing',
    # amoCRM
    'sync_crm_client_to_amocrm_contact_task',
    'resync_all_crm_clients_to_amocrm_task',
    'process_amocrm_contacts_webhook_task',
]
