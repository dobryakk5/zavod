from types import SimpleNamespace

from django.test import SimpleTestCase, override_settings

from .telegram_client import TelegramPublisher
from .social_publishers import build_absolute_media_url
from .tasks.publishing import _compose_post_text
from .services.product_relations import merge_related_products, remove_related_product


class TelegramPublisherSplitTests(SimpleTestCase):
    def setUp(self):
        self.publisher = TelegramPublisher(api_id="123", api_hash="456")

    def test_extract_first_chunk_prefers_sentence_boundary(self):
        text = "Sentence one. Sentence two remains in the feed."
        chunk, remainder = self.publisher._extract_first_chunk(text, 25)

        self.assertEqual(chunk, "Sentence one.")
        self.assertEqual(remainder, "Sentence two remains in the feed.")

    def test_extract_first_chunk_falls_back_to_space(self):
        text = "Alpha beta gamma"
        chunk, remainder = self.publisher._extract_first_chunk(text, 11)

        self.assertEqual(chunk, "Alpha beta")
        self.assertEqual(remainder, "gamma")

    def test_extract_first_chunk_hard_limit_without_breaks(self):
        text = "Supercalifragilisticexpialidocious"
        chunk, remainder = self.publisher._extract_first_chunk(text, 10)

        self.assertEqual(chunk, "Supercalif")
        self.assertEqual(remainder, "ragilisticexpialidocious")


class ComposePostTextTests(SimpleTestCase):
    def test_includes_title_and_body(self):
        post = SimpleNamespace(title="Headline", text="Body text", publish_text=True)
        self.assertEqual(_compose_post_text(post), "Headline\n\nBody text")

    def test_only_title_when_body_missing(self):
        post = SimpleNamespace(title="Headline", text="   ", publish_text=True)
        self.assertEqual(_compose_post_text(post), "Headline")

    def test_respects_publish_text_flag(self):
        post = SimpleNamespace(title="Headline", text="Body text", publish_text=False)
        self.assertEqual(_compose_post_text(post), "")

    def test_only_body_when_no_title(self):
        post = SimpleNamespace(title="", text="Body text", publish_text=True)
        self.assertEqual(_compose_post_text(post), "Body text")


class BuildAbsoluteMediaUrlTests(SimpleTestCase):
    @override_settings(WAGTAILADMIN_BASE_URL="https://example.com")
    def test_relative_media_url(self):
        self.assertEqual(
            build_absolute_media_url("/media/post_images/photo.jpg"),
            "https://example.com/media/post_images/photo.jpg",
        )

    def test_keeps_absolute_url(self):
        url = "https://cdn.example.com/media/video.mp4"
        self.assertEqual(build_absolute_media_url(url), url)

    @override_settings(WAGTAILADMIN_BASE_URL=None, PUBLIC_MEDIA_BASE_URL=None)
    def test_returns_none_without_base(self):
        self.assertIsNone(build_absolute_media_url("/media/photo.jpg"))


class MergeRelatedProductsTests(SimpleTestCase):
    def test_prepends_and_dedupes_dict_id(self):
        existing = [{"id": 10, "name": "old"}, {"id": 11, "name": "keep"}]
        new_ref = {"id": 10, "name": "new"}
        self.assertEqual(merge_related_products(existing, new_ref), [new_ref, {"id": 11, "name": "keep"}])

    def test_dedupes_int_and_string_forms(self):
        existing = [10, "10", {"id": "10", "name": "old"}, {"id": 12}]
        new_ref = {"id": 10, "name": "new"}
        self.assertEqual(merge_related_products(existing, new_ref), [new_ref, {"id": 12}])

    def test_remove_by_id(self):
        existing = [{"id": "10", "name": "a"}, 11, {"id": 12, "name": "b"}]
        self.assertEqual(remove_related_product(existing, 10), [11, {"id": 12, "name": "b"}])
