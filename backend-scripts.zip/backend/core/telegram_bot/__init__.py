"""Telegram bot helpers."""
