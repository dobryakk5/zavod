"""
CRM service helpers.
"""

